Lucas Abaitua y Estefania Oñate
DESPLEGAR PROYECTO MEDIANTE DOCKER
Tendremos en la carpeta docker-lamp-master un archivo dockerfile y docker-compose.yml, un archivo sql que será nuestra base de datos y por último una carpeta app donde se encontrarán nuestros archivos para el funcionamiento de nuestro proyecto (archivos html, php, js, css).
nota: donde se encuentre "usuario" debe ponerse el usuario de ubuntu de la persona que lo ejecuta.
PASO 1:
En la terminal hay que situarse en /home/usuario/docker-lamp-master con el comando cd
PASO 2:
Para construir la imagen web pondremos en la terminal: "sudo docker build -t="web" . "
PASO 3:
Para desplegar los servicios: "sudo docker-compose up o sudo docker-compose up -d "
PASO 4:
Visitamos la web "localhost:8890" y pondremos como usuario "admin" y como contraseña "test". Una vez dentro importamos en la base de datos llamada "database" lo siguiente: /home/usuario/docker-lamp-master/database.sql que sería nuestra base de datos
PASO 5:
Visitamos la web localhost:81 para acceder al proyecto y probar todas las funcionalidades.
PASO 6:
Para parar los servicios: pulsar ctrl+C y tras haberse parado se puede usar "sudo docker-compose down".
